import { IUnsubscribe } from '@lirx/unsubscribe';

export type IRemoveEventListener = IUnsubscribe;

export type ICreateEventListenerTarget = Pick<EventTarget, 'addEventListener' | 'removeEventListener'>;

// https://www.hacklewayne.com/typescript-convert-union-to-tuple-array-yes-but-how
type Contra<T> =
  T extends any
    ? (arg: T) => void
    : never;

type InferContra<T> =
  [T] extends [(arg: infer I) => void]
    ? I
    : never;

type PickOne<T> = InferContra<InferContra<Contra<Contra<T>>>>;

type UnionToTuple<T> =
  PickOne<T> extends infer U                  // assign PickOne<T> to U
    ? Exclude<T, U> extends never               // T and U are the same
      ? [T]
      : [...UnionToTuple<Exclude<T, U>>, U]    // recursion
    : never;


// // https://catchts.com/union-array
// type UnionToIntersection<U> = (U extends any ? (k: U) => void : never) extends (
//     k: infer I
//   ) => void
//   ? I
//   : never;
//
// type UnionToOvlds<U> = UnionToIntersection<
//   U extends any ? (f: U) => void : never
// >;
//
// type PopUnion<U> = UnionToOvlds<U> extends (a: infer A) => void ? A : never;
//
// type IsUnion<T> = [T] extends [UnionToIntersection<T>] ? false : true;
//
// // Finally me)
// type UnionToArray<T, A extends unknown[] = []> = IsUnion<T> extends true
//   ? UnionToArray<Exclude<T, PopUnion<T>>, [PopUnion<T>, ...A]>
//   : [T, ...A];

export type InferCreateEventListenerTargetArguments<GTarget extends ICreateEventListenerTarget, GType extends string> =
  GTarget extends {
      // addEventListener<K extends string>(type: K, listener: (this: HTMLElement, ev: (infer U)) => any, options?: boolean | AddEventListenerOptions): void;
      // addEventListener<K extends string>(type: infer GType, listener: (this: HTMLElement, ev: (infer GEvent)) => any, options?: boolean | AddEventListenerOptions): void;
      // addEventListener<K extends 'animationcancel'>(type: K, listener: (this: HTMLElement, ev: infer U) => any, options?: boolean | AddEventListenerOptions): void;
      // addEventListener<K extends keyof infer U>(type: K, listener: (this: HTMLElement, ev: (infer U)[K]) => any, options?: boolean | AddEventListenerOptions): void;
      // addEventListener<GType>(type: GType, listener: (this: HTMLElement, ev: (infer U)) => any, options?: boolean | AddEventListenerOptions): void;
      // addEventListener<K extends GType>(type: GType, listener: (this: HTMLElement, ev: Record<GType, infer U>[GType]) => any, options?: boolean | AddEventListenerOptions): void;
      addEventListener<K extends GType>(type: GType, listener: infer U, options?: boolean | AddEventListenerOptions): void;
      // addEventListener<K extends 'click'>(type: 'click', listener: (this: HTMLElement, ev: infer V) => any, options?: boolean | AddEventListenerOptions): void;
      // addEventListener<K extends string>(type: infer GType, ...args: infer GArgumentsA): void;
      // addEventListener<K extends string>(...args: infer GArgumentsA): void;
      // addEventListener<K extends keyof (infer U)>(...args: infer GArgumentsA): void;
      addEventListener(...args: infer GArgumentsB): void;
    }
    // ? {
    //   [GKey in Extract<GType, string>]: string;
    // }
  ? U
    // ? GArgumentsA | GArgumentsB
    : never;

export function createEventListener<GTarget extends ICreateEventListenerTarget>(
  target: GTarget,
  ...[type, listener, options]: InferCreateEventListenerTargetArguments<GTarget>
): IRemoveEventListener {
  target.addEventListener(type, listener, options);
  return (): void => {
    target.removeEventListener(type, listener, options);
  };
}


// const so: PickOne<'a'|'b'|'c'|'d'|'e'>;
// const so: Union2Tuple<'a'|'b'|'c'|'d'|'e'> = ['a', 'b', 'c', 'd', 'e'];

type I = InferCreateEventListenerTargetArguments<HTMLElement, 'click'>;
type J = InferCreateEventListenerTargetArguments<EventTarget>;
type G = 'a' | string;

const a = createEventListener(window, 'click', (event: MouseEvent) => {
});
window.addEventListener('', a);

function h(g: G) {

}

h('');
