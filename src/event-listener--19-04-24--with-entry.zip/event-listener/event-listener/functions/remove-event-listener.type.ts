import { IUnsubscribe } from '@lirx/unsubscribe';

export type IRemoveEventListener = IUnsubscribe;
