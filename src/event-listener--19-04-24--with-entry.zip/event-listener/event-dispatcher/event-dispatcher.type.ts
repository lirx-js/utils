import { IDispatchEventMethod } from './methods/dispatch-event-method.type';

export interface IEventDispatcher extends IDispatchEventMethod {}
