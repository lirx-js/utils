import { IEventListener } from '../event-listener.type.js';
import { InferEventListenerEntryFromGenericEventTarget } from './infer-event-listener-entry-from-event-target.type.js';

export type InferEventListenerFromGenericEventTarget<GEventTarget> = IEventListener<
  InferEventListenerEntryFromGenericEventTarget<GEventTarget>
>;
