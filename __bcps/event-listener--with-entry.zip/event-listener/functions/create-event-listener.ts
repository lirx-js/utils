import { IEventListener } from '../event-listener.type.js';
import { IEventListenerHandlerOrNull } from '../types/event-listener-handler.type.js';
import { IRemoveEventListener } from './remove-event-listener.type.js';

export function createEventListener(
  target: IEventListener,
  type: string,
  listener: IEventListenerHandlerOrNull,
  options?: boolean | AddEventListenerOptions,
): IRemoveEventListener {
  target.addEventListener(type, listener, options);
  return (): void => {
    target.removeEventListener(type, listener, options);
  };
}
