import { genericEventTargetToTypedEventListener } from '../event-map/generic-event-target-to-typed-event-listener.js';
import { InferEventListenerEntryFromGenericEventTarget } from '../event-map/infer-event-listener-entry-from-event-target.type.js';
import { InferEventListenerEntryGType } from '../types/entry/event-listener-entry.type.js';
import {
  IEventListenerHandlerOrNull,
  InferEventListenerHandlerFromEventListenerEntryAndType,
} from '../types/event-listener-handler.type.js';
import { createEventListener } from './create-event-listener.js';
import { IRemoveEventListener } from './remove-event-listener.type.js';

export function createEventListenerFromGenericEventTarget<
  GEventTarget,
  GType extends InferEventListenerEntryGType<
    InferEventListenerEntryFromGenericEventTarget<GEventTarget>
  >,
>(
  target: GEventTarget,
  type: GType,
  listener: InferEventListenerHandlerFromEventListenerEntryAndType<
    InferEventListenerEntryFromGenericEventTarget<GEventTarget>,
    GType
  >,
  options?: boolean | AddEventListenerOptions,
): IRemoveEventListener {
  return createEventListener(
    genericEventTargetToTypedEventListener(target),
    type,
    listener as IEventListenerHandlerOrNull,
    options,
  );
}
