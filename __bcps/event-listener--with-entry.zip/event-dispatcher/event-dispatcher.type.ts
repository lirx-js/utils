import { IDispatchEventMethod } from './methods/dispatch-event-method.type.js';

export interface IEventDispatcher extends IDispatchEventMethod {}
