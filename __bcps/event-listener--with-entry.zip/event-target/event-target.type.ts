import { IEventDispatcher } from '../event-dispatcher/event-dispatcher.type.js';
import { IEventListener } from '../event-listener/event-listener.type.js';
import { IEventListenerEntry } from '../event-listener/types/entry/event-listener-entry.type.js';

export interface IEventTarget<GEntry extends IEventListenerEntry = IEventListenerEntry>
  extends IEventListener<GEntry>,
    IEventDispatcher {}
